'use strict'

module.exports = {
  ONE_SECOND: 1000
}
